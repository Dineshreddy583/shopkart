import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Search, User, Menu, Heart, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';

export const Header = () => {
  const { itemCount } = useCart();
  const location = useLocation();
  const isAdmin = location.pathname.startsWith('/admin');

  if (isAdmin) return null;

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground py-2">
        <div className="container mx-auto px-4 flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              <span>Deliver to Mumbai 400001</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span>Free shipping on orders above ₹999</span>
            <span>•</span>
            <span>24/7 Customer Support</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-primary to-secondary p-2 rounded-lg">
              <ShoppingCart className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              ShopKart
            </span>
          </Link>

          {/* Search Bar */}
          <div className="flex-1 max-w-2xl mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search for products, brands and more..."
                className="pl-10 h-12 bg-muted border-0 focus:bg-card focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <User className="h-5 w-5" />
              <span className="hidden md:inline">Login</span>
            </Button>
            
            <Link to="/admin">
              <Button variant="outline" size="sm" className="hidden md:flex text-xs">
                Admin
              </Button>
            </Link>

            <Button variant="ghost" size="sm" className="relative">
              <Heart className="h-5 w-5" />
              <span className="hidden md:inline ml-2">Wishlist</span>
            </Button>

            <Link to="/cart">
              <Button variant="ghost" size="sm" className="relative flex items-center gap-2">
                <ShoppingCart className="h-5 w-5" />
                <span className="hidden md:inline">Cart</span>
                {itemCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-secondary text-secondary-foreground text-xs">
                    {itemCount}
                  </Badge>
                )}
              </Button>
            </Link>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mt-4 flex items-center gap-6 text-sm">
          <Link to="/categories/electronics" className="hover:text-primary transition-colors">
            Electronics
          </Link>
          <Link to="/categories/fashion" className="hover:text-primary transition-colors">
            Fashion
          </Link>
          <Link to="/categories/home" className="hover:text-primary transition-colors">
            Home & Kitchen
          </Link>
          <Link to="/categories/books" className="hover:text-primary transition-colors">
            Books
          </Link>
          <Link to="/categories/sports" className="hover:text-primary transition-colors">
            Sports
          </Link>
          <Link to="/deals" className="text-price font-medium hover:text-price/80 transition-colors">
            Today's Deals
          </Link>
        </nav>
      </div>
    </header>
  );
};