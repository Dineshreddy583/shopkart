import { Product } from '../contexts/CartContext';
import samsungGalaxy from '../assets/samsung-galaxy.jpg';
import nikeShoes from '../assets/nike-shoes.jpg';
import macbookAir from '../assets/macbook-air.jpg';
import sonyHeadphones from '../assets/sony-headphones.jpg';
import levisJeans from '../assets/levis-jeans.jpg';
import adidasUltraboost from '../assets/adidas-ultraboost.jpg';
import ipadPro from '../assets/ipad-pro.jpg';
import hmTshirt from '../assets/hm-tshirt.jpg';
import canonCamera from '../assets/canon-camera.jpg';
import zaraBlazer from '../assets/zara-blazer.jpg';

export const products: Product[] = [
  {
    id: '1',
    name: 'Samsung Galaxy S23 Ultra',
    price: 124999,
    image: samsungGalaxy,
    description: 'Latest flagship smartphone with 200MP camera and S Pen',
    category: 'Electronics',
    stock: 15,
    rating: 4.8,
    discount: 10
  },
  {
    id: '2',
    name: 'Nike Air Max 270',
    price: 12995,
    image: nikeShoes,
    description: 'Comfortable running shoes with Air Max technology',
    category: 'Fashion',
    stock: 25,
    rating: 4.5
  },
  {
    id: '3',
    name: 'MacBook Air M2',
    price: 114900,
    image: macbookAir,
    description: '13-inch laptop with M2 chip, 8GB RAM, 256GB SSD',
    category: 'Electronics',
    stock: 8,
    rating: 4.9,
    discount: 5
  },
  {
    id: '4',
    name: 'Levi\'s 511 Slim Jeans',
    price: 3499,
    image: levisJeans,
    description: 'Classic slim-fit jeans in dark wash',
    category: 'Fashion',
    stock: 30,
    rating: 4.3
  },
  {
    id: '5',
    name: 'Sony WH-1000XM5',
    price: 29990,
    image: sonyHeadphones,
    description: 'Premium noise-canceling wireless headphones',
    category: 'Electronics',
    stock: 12,
    rating: 4.7,
    discount: 15
  },
  {
    id: '6',
    name: 'Adidas Ultraboost 22',
    price: 16999,
    image: adidasUltraboost,
    description: 'Energy-returning running shoes with Boost midsole',
    category: 'Fashion',
    stock: 20,
    rating: 4.6
  },
  {
    id: '7',
    name: 'iPad Pro 11-inch',
    price: 81900,
    image: ipadPro,
    description: 'Powerful tablet with M2 chip and 11-inch Liquid Retina display',
    category: 'Electronics',
    stock: 10,
    rating: 4.8,
    discount: 8
  },
  {
    id: '8',
    name: 'H&M Cotton T-Shirt',
    price: 799,
    image: hmTshirt,
    description: 'Basic cotton t-shirt in various colors',
    category: 'Fashion',
    stock: 50,
    rating: 4.0
  },
  {
    id: '9',
    name: 'Canon EOS R6 Mark II',
    price: 239995,
    image: canonCamera,
    description: 'Full-frame mirrorless camera with 24.2MP sensor',
    category: 'Electronics',
    stock: 5,
    rating: 4.9,
    discount: 12
  },
  {
    id: '10',
    name: 'Zara Formal Blazer',
    price: 5999,
    image: zaraBlazer,
    description: 'Professional blazer for office and formal occasions',
    category: 'Fashion',
    stock: 18,
    rating: 4.4
  }
];

export const categories = [
  'All',
  'Electronics',
  'Fashion',
  'Home & Kitchen',
  'Books',
  'Sports'
];