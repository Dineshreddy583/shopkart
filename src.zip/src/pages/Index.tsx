import { HomePage } from './HomePage';

// This redirects to the main HomePage component
const Index = () => {
  return <HomePage />;
};

export default Index;
