import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ShoppingCart, 
  Package, 
  Users, 
  TrendingUp, 
  ArrowUp, 
  ArrowDown,
  Eye,
  Edit,
  Trash2
} from 'lucide-react';
import { products } from '@/data/products';

export const AdminDashboard = () => {
  // Mock analytics data
  const stats = {
    totalSales: 1250000,
    totalOrders: 850,
    totalProducts: products.length,
    totalUsers: 1200,
    salesGrowth: 12.5,
    ordersGrowth: 8.3,
    productsGrowth: 15.2,
    usersGrowth: 22.1
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(amount);
  };

  const recentOrders = [
    { id: 'ORD001', customer: 'Rahul Sharma', amount: 24999, status: 'Delivered', date: '2024-01-15' },
    { id: 'ORD002', customer: 'Priya Singh', amount: 8499, status: 'Shipped', date: '2024-01-15' },
    { id: 'ORD003', customer: 'Amit Kumar', amount: 15999, status: 'Processing', date: '2024-01-14' },
    { id: 'ORD004', customer: 'Sneha Patel', amount: 3299, status: 'Pending', date: '2024-01-14' },
    { id: 'ORD005', customer: 'Vikash Gupta', amount: 12999, status: 'Delivered', date: '2024-01-13' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Delivered': return 'bg-success text-success-foreground';
      case 'Shipped': return 'bg-primary text-primary-foreground';
      case 'Processing': return 'bg-warning text-warning-foreground';
      case 'Pending': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your e-commerce store performance</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalSales)}</div>
            <div className="flex items-center text-xs text-success">
              <ArrowUp className="h-4 w-4 mr-1" />
              +{stats.salesGrowth}% from last month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalOrders.toLocaleString()}</div>
            <div className="flex items-center text-xs text-success">
              <ArrowUp className="h-4 w-4 mr-1" />
              +{stats.ordersGrowth}% from last month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Products</CardTitle>
            <Package className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalProducts}</div>
            <div className="flex items-center text-xs text-success">
              <ArrowUp className="h-4 w-4 mr-1" />
              +{stats.productsGrowth}% from last month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
            <div className="flex items-center text-xs text-success">
              <ArrowUp className="h-4 w-4 mr-1" />
              +{stats.usersGrowth}% from last month
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  <div>
                    <p className="font-medium">{order.id}</p>
                    <p className="text-sm text-muted-foreground">{order.customer}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="font-medium">{formatCurrency(order.amount)}</p>
                    <p className="text-sm text-muted-foreground">{order.date}</p>
                  </div>
                  
                  <Badge className={getStatusColor(order.status)}>
                    {order.status}
                  </Badge>
                  
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button className="w-full justify-start" variant="outline">
              <Package className="h-4 w-4 mr-2" />
              Add New Product
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <Users className="h-4 w-4 mr-2" />
              Manage Users
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <TrendingUp className="h-4 w-4 mr-2" />
              View Analytics
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Low Stock Alert</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {products.filter(p => p.stock <= 5).slice(0, 3).map((product) => (
                <div key={product.id} className="flex justify-between items-center p-2 bg-warning/10 rounded">
                  <span className="text-sm font-medium">{product.name}</span>
                  <Badge variant="outline" className="text-warning">
                    {product.stock} left
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Selling</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {products.filter(p => p.rating >= 4.7).slice(0, 3).map((product, index) => (
                <div key={product.id} className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-muted-foreground">#{index + 1}</span>
                    <span className="text-sm">{product.name}</span>
                  </div>
                  <Badge variant="outline">
                    ⭐ {product.rating}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};